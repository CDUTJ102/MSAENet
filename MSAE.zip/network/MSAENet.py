# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
from backbone.origin.from_origin import Backbone_VGG16_in3
from module.BaseBlocks import BasicConv2d
from module.MyModule import *
from module.Module import *
from utils.tensor_ops import cus_sample
from backbone.origin.res2net_v1b_base import Res2Net_model
from backbone.origin.swin import *

#VGG-16 backbone
class MSAENet(nn.Module):
    def __init__(self):
        super(MSAENet, self).__init__()

        self.upsample = cus_sample

        (
            self.encoder1,
            self.encoder2,
            self.encoder4,
            self.encoder8,
            self.encoder16,
        ) = Backbone_VGG16_in3()

        self.res1 = MSAM1(64, 64)
        self.res2 = MSAM1(128, 128)
        self.res3 = MSAM1(256, 256)
        self.res4 = MSAM1(512, 512)
        self.res5 = MSAM1(512, 512)

        self.o1 = MSCM(64)
        self.o2 = MSCM(128)
        self.o3 = MSCM(256)
        self.e4 = MSAM(512)
        self.e5 = MSAM(512)
        self.gcnlayer = DSIModule(1280)


        #1*1 conv change channel
        self.con_AIM5 = nn.Conv2d(512, 64, 3, 1, 1)
        self.con_AIM4 = nn.Conv2d(512, 64, 3, 1, 1)
        self.con_AIM3 = nn.Conv2d(256, 64, 3, 1, 1)
        self.con_AIM2 = nn.Conv2d(128, 64, 3, 1, 1)
        self.con_AIM1 = nn.Conv2d(64, 32, 3, 1, 1)

        # U形结构解码器
        self.gam =GAM(64)
        self.cpa = CPA(64)
        # MSIM Module
        self.MSCM16 = MSIM(64)
        self.MSCM8 = MSIM(64)
        self.MSCM4 = MSIM(64)
        self.MSCM2 = MSIM(32)

        self.erm = ERM(32)

        self.upconv16 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv8 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv4 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv2 = BasicConv2d(64, 32, kernel_size=3, stride=1, padding=1)
        self.upconv1 = BasicConv2d(32, 32, kernel_size=3, stride=1, padding=1)


        self.classifier = nn.Conv2d(32, 1, 1)
        self.classifierp6 = nn.Conv2d(64, 1, 1)
        self.predtrans = nn.Conv2d(1, 1, kernel_size=3, padding=1)
        self.predtrans64 = nn.Conv2d(64, 1, kernel_size=3, padding=1)

        self.EGM = EGM(32)


    def forward(self, in_data):
            in_data_1 = self.encoder1(in_data)
            # 64通道    256  256
            in_data_2 = self.encoder2(in_data_1)
            # 128通道  128  128 size
            in_data_4 = self.encoder4(in_data_2)
            # 256通道  64*64
            in_data_8 = self.encoder8(in_data_4)
            #  512通道  32*32
            in_data_16 = self.encoder16(in_data_8)
            # 512 通道   16*16

            in_data_1 = self.res1(in_data_1)
            in_data_2 = self.res2(in_data_2)
            in_data_4 = self.res3(in_data_4)
            in_data_8 = self.res4(in_data_8)
            in_data_16 = self.res5(in_data_16)

            xg = self.gcnlayer(in_data_1, in_data_2, in_data_4, in_data_8,  in_data_16)
            in_data_16 = self.e5(in_data_16, xg)
            in_data_8 = self.e4(in_data_8, in_data_16)
            in_data_4 = self.o3(in_data_4, in_data_8)
            in_data_2 = self.o2(in_data_2, in_data_4)
            in_data_1 = self.o1(in_data_1, in_data_2)

            # 1*1 CONV CHANGE CHANNEL   通道卷积
            in_data_1 = self.con_AIM1(in_data_1)
            in_data_2 = self.con_AIM2(in_data_2)
            in_data_4 = self.con_AIM3(in_data_4)
            in_data_8 = self.con_AIM4(in_data_8)
            in_data_16 = self.con_AIM5(in_data_16)
            # 64通道变32通道


            p5 =in_data_16
            out_data_16 = self.upconv16(p5)


            out_data_8 = self.MSCM16(in_data_8,out_data_16)
            p4 = out_data_8

            out_data_8 = self.upconv8(p4)  # 512

            out_data_4 = self.MSCM8(in_data_4,out_data_8)
            p3 = out_data_4
            out_data_4 = self.upconv4(p3)  # 256


            out_data_2 = self.MSCM4(in_data_2,out_data_4)
            p2 = out_data_2
            out_data_2 = self.upconv2(p2)  # 64

            out_data_1 = self.MSCM2(in_data_1,out_data_2)
            f1 = out_data_1
            out_data_1 = self.upconv1(f1)  # 32


            out_data = self.classifier(out_data_1)
            p1 = out_data

            s1 = F.interpolate(self.predtrans(p1), size=in_data.size()[2:], mode='bilinear')
            s2 = F.interpolate(self.predtrans64(p2), size=in_data.size()[2:], mode='bilinear')
            s3 = F.interpolate(self.predtrans64(p3), size=in_data.size()[2:], mode='bilinear')
            s4 = F.interpolate(self.predtrans64(p4), size=in_data.size()[2:], mode='bilinear')
            # erm
            e1, e2 = self.EGM(in_data, torch.sigmoid(s1))

            return s1, e1, e2, s2, s3, s4

