# -*- coding: utf-8 -*-
import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim.lr_scheduler as sche
from torch.optim.optimizer import *
# import torch.optim.optimizer as optimizer
from torch.optim import optimizer
from torch.optim import SGD, Adam
from utils.misc import construct_print



def save_checkpoint(
    model: nn.Module = None,
    optimizer: optimizer.Optimizer = None,
    scheduler: sche._LRScheduler = None,
    amp=None,
    exp_name: str = "",
    current_epoch: int = 1,
    full_net_path: str = "",
    state_net_path: str = "",
):
    """
    保存完整参数模型（大）和状态参数模型（小）

    Args:
        model (nn.Module): model object
        optimizer (optim.Optimizer): optimizer object
        scheduler (sche._LRScheduler): scheduler object
        amp (): apex.amp
        exp_name (str): exp_name
        current_epoch (int): in the epoch, model **will** be trained
        full_net_path (str): the path for saving the full model parameters
        state_net_path (str): the path for saving the state dict.
    """

    state_dict = {
        "arch": exp_name,
        "epoch": current_epoch,
        "net_state": model.state_dict(),
        "opti_state": optimizer.state_dict(),
        "sche_state": scheduler.state_dict(),
        "amp_state": amp.state_dict() if amp else None,
    }
    torch.save(state_dict, full_net_path)
    torch.save(model.state_dict(), state_net_path)

def resume_checkpoint(
    model: nn.Module = None,
    optimizer: optimizer.Optimizer = None,
    scheduler: sche._LRScheduler = None,
    amp=None,
    exp_name: str = "",
    load_path: str = "",
    mode: str = "all",
):
    """
    从保存节点恢复模型

    Args:
        model (nn.Module): model object
        optimizer (optim.Optimizer): optimizer object
        scheduler (sche._LRScheduler): scheduler object
        amp (): apex.amp
        exp_name (str): exp_name
        load_path (str): 模型存放路径
        mode (str): 选择哪种模型恢复模式:
            - 'all': 回复完整模型，包括训练中的参数；
            - 'onlynet': 仅恢复模型权重参数

    Returns:
        int: start_epoch 如果 mode='all' 且加载成功，否则返回0
    """
    if load_path and os.path.exists(load_path) and os.path.isfile(load_path):
        construct_print(f"Loading checkpoint '{load_path}'")
        checkpoint = torch.load(load_path)
        if mode == "all":
            if exp_name and exp_name != checkpoint.get("arch", ""):
                raise Exception(f"We can not match {exp_name} with {load_path}.")
            start_epoch = checkpoint.get("epoch", 0)
            if hasattr(model, "module"):
                model.module.load_state_dict(checkpoint["net_state"])
            else:
                model.load_state_dict(checkpoint["net_state"])
            if optimizer and "opti_state" in checkpoint:
                optimizer.load_state_dict(checkpoint["opti_state"])
            if scheduler and "sche_state" in checkpoint:
                scheduler.load_state_dict(checkpoint["sche_state"])
            if "amp_state" in checkpoint:
                if amp:
                    amp.load_state_dict(checkpoint["amp_state"])
                else:
                    construct_print("You are not using amp.")
            else:
                construct_print("The state_dict of amp is None.")
            construct_print(
                f"Loaded '{load_path}' (will train at epoch {checkpoint.get('epoch', 0)})"
            )
            return checkpoint.get("epoch", 0)
        elif mode == "onlynet":
            if hasattr(model, "module"):
                model.module.load_state_dict(checkpoint)
            else:
                model.load_state_dict(checkpoint)
            construct_print(
                f"Loaded checkpoint '{load_path}' (only has the model's weight params)"
            )
            return 0
        else:
            raise NotImplementedError
    else:
        if load_path:
            construct_print(f"Checkpoint path '{load_path}' is invalid. Skipping loading.")
        return 0  # 从第0个 epoch 开始

# def resume_checkpoint(
#     model: nn.Module = None,
#     optimizer: optimizer.Optimizer = None, #
#     scheduler: sche._LRScheduler = None,
#     amp=None,
#     exp_name: str = "",
#     load_path: str = "",
#     mode: str = "all",
# ):
#     """
#     从保存节点恢复模型
#
#     Args:
#         model (nn.Module): model object
#         optimizer (optim.Optimizer): optimizer object
#         scheduler (sche._LRScheduler): scheduler object
#         amp (): apex.amp
#         exp_name (str): exp_name
#         load_path (str): 模型存放路径
#         mode (str): 选择哪种模型恢复模式:
#             - 'all': 回复完整模型，包括训练中的的参数；
#             - 'onlynet': 仅恢复模型权重参数
#
#     Returns mode: 'all' start_epoch; 'onlynet' None
#     """
#     if os.path.exists(load_path) and os.path.isfile(load_path):
#         construct_print(f"Loading checkpoint '{load_path}'")
#         checkpoint = torch.load(load_path)
#         if mode == "all":
#             if exp_name and exp_name != checkpoint["arch"]:
#                 # 如果给定了exp_name，那么就必须匹配对应的checkpoint["arch"]，否则不作要求
#                 raise Exception(f"We can not match {exp_name} with {load_path}.")
#
#             start_epoch = checkpoint["epoch"]
#             if hasattr(model, "module"):
#                 # model.module.load_state_dict(checkpoint["net_state"])
#                 model.load_state_dict(checkpoint["net_state"])
#             else:
#                 model.load_state_dict(checkpoint["net_state"])
#             optimizer.load_state_dict(checkpoint["opti_state"])
#             scheduler.load_state_dict(checkpoint["sche_state"])
#             if checkpoint.get("amp_state", None):
#                 if amp:
#                     amp.load_state_dict(checkpoint["amp_state"])
#                 else:
#                     construct_print("You are not using amp.")
#             else:
#                 construct_print("The state_dict of amp is None.")
#             construct_print(
#                 f"Loaded '{load_path}' " f"(will train at epoch" f" {checkpoint['epoch']})"
#             )
#             return start_epoch
#         elif mode == "onlynet":
#             if hasattr(model, "module"):
#                 # model.module.load_state_dict(checkpoint)
#                 model.load_state_dict(checkpoint)
#             else:
#                 model.load_state_dict(checkpoint)
#             construct_print(
#                 f"Loaded checkpoint '{load_path}' " f"(only has the model's weight params)"
#             )
#         else:
#             raise NotImplementedError
#     else:
#         raise Exception(f"{load_path}路径不正常，请检查")


def make_scheduler(
    optimizer: optimizer.Optimizer, total_num: int, scheduler_type: str, scheduler_info: dict
) -> sche._LRScheduler:
    def get_lr_coefficient(curr_epoch):
        nonlocal total_num
        # curr_epoch start from 0
        # total_num = iter_num if args["sche_usebatch"] else end_epoch
        if scheduler_type == "poly":
            coefficient = pow((1 - float(curr_epoch) / total_num), scheduler_info["lr_decay"])
        elif scheduler_type == "poly_warmup":
            turning_epoch = scheduler_info["warmup_epoch"]
            if curr_epoch < turning_epoch:
                # 0,1,2,...,turning_epoch-1
                coefficient = 1 / turning_epoch * (1 + curr_epoch)
            else:
                # turning_epoch,...,end_epoch
                curr_epoch -= turning_epoch - 1
                total_num -= turning_epoch - 1
                coefficient = pow((1 - float(curr_epoch) / total_num), scheduler_info["lr_decay"])
        elif scheduler_type == "cosine_warmup":
            turning_epoch = scheduler_info["warmup_epoch"]
            if curr_epoch < turning_epoch:
                # 0,1,2,...,turning_epoch-1
                coefficient = 1 / turning_epoch * (1 + curr_epoch)
            else:
                # turning_epoch,...,end_epoch
                curr_epoch -= turning_epoch - 1
                total_num -= turning_epoch - 1
                coefficient = (1 + np.cos(np.pi * curr_epoch / total_num)) / 2
        elif scheduler_type == "f3_sche":
            coefficient = 1 - abs((curr_epoch + 1) / (total_num + 1) * 2 - 1)
        else:
            raise NotImplementedError
        return coefficient

    scheduler = sche.LambdaLR(optimizer, lr_lambda=get_lr_coefficient)
    return scheduler


def make_optimizer(model: nn.Module, optimizer_type: str, optimizer_info: dict) -> optimizer.Optimizer:
    if optimizer_type == "sgd_trick":
        # https://github.com/implus/PytorchInsight/blob/master/classification/imagenet_tricks.py
        params = [
            {
                "params": [
                    p for name, p in model.named_parameters() if ("bias" in name or "bn" in name)
                ],
                "weight_decay": 0,
            },
            {
                "params": [
                    p
                    for name, p in model.named_parameters()
                    if ("bias" not in name and "bn" not in name)
                ]
            },
        ]
        optimizer = SGD(
            params,
            lr=optimizer_info["lr"],
            momentum=optimizer_info["momentum"],
            weight_decay=optimizer_info["weight_decay"],
            nesterov=optimizer_info["nesterov"],
        )
    elif optimizer_type == "sgd_r3":
        params = [
            # 不对bias参数执行weight decay操作，weight decay主要的作用就是通过对网络
            # 层的参数（包括weight和bias）做约束（L2正则化会使得网络层的参数更加平滑）达
            # 到减少模型过拟合的效果。
            {
                "params": [
                    param for name, param in model.named_parameters() if name[-4:] == "bias"
                ],
                "lr": 2 * optimizer_info["lr"],
            },
            {
                "params": [
                    param for name, param in model.named_parameters() if name[-4:] != "bias"
                ],
                "lr": optimizer_info["lr"],
                "weight_decay": optimizer_info["weight_decay"],
            },
        ]
        optimizer = SGD(params, momentum=optimizer_info["momentum"])
    elif optimizer_type == "sgd_all":
        optimizer = SGD(
            model.parameters(),
            lr=optimizer_info["lr"],
            weight_decay=optimizer_info["weight_decay"],
            momentum=optimizer_info["momentum"],
        )
    elif optimizer_type == "adam":
        optimizer = Adam(
            model.parameters(),
            lr=optimizer_info["lr"],
            betas=(0.9, 0.999),
            eps=1e-8,
            weight_decay=optimizer_info["weight_decay"],
        )
    elif optimizer_type == "f3_trick":
        backbone, head = [], []
        for name, params_tensor in model.named_parameters():
            if name.startswith("div_2"):
                pass
            elif name.startswith("div"):
                backbone.append(params_tensor)
            else:
                head.append(params_tensor)
        params = [
            {"params": backbone, "lr": 0.1 * optimizer_info["lr"]},
            {"params": head, "lr": optimizer_info["lr"]},
        ]
        optimizer = SGD(
            params=params,
            momentum=optimizer_info["momentum"],
            weight_decay=optimizer_info["weight_decay"],
            nesterov=optimizer_info["nesterov"],
        )
    else:
        raise NotImplementedError

    print("optimizer = ", optimizer)
    return optimizer


if __name__ == "__main__":
    a = torch.rand((3, 3)).bool()
    print(isinstance(a, torch.FloatTensor), a.type())
