# 邓浩
# 开发时间：2024/12/17 11:26
from torch_geometric.nn import  BatchNorm, global_max_pool
from torch.nn import Sequential as Seq, Linear, ReLU, BatchNorm1d
from torch_geometric.nn.conv import MessagePassing
from torch_cluster import knn_graph
from torch import nn


def map(data,MIN,MAX):
    d_min = torch.max(data)
    d_max = torch.min(data)
    return MIN + (MAX-MIN)/(d_max-d_min + 0.0001) * (data - d_min)



class Gatedgcn(MessagePassing):
    def __init__(self, in_channels, out_channels):
        super(Gatedgcn, self).__init__(aggr='add')  # "Max" aggregation. ['add', 'mean', 'max']
        self.linA = torch.nn.Linear(in_channels, out_channels)
        self.linB = torch.nn.Linear(in_channels, out_channels)
        self.linU = torch.nn.Linear(in_channels, out_channels)
        self.linV = torch.nn.Linear(in_channels, out_channels)

    def forward(self, x, edge_index):
        # x0 has shape [N, in_channels]
        # edge_index has shape [2, E]
        # edge_index, _ = remove_self_loops(edge_index)
        x = x.unsqueeze(-1) if x.dim() == 1 else x
        return self.propagate(edge_index, size=(x.size(0), x.size(0)), x=x)

    def message(self, x_i, x_j):  # massage flow from node_j to node_i
        # # x_i has shape [E, in_channels]
        # # x_j has shape [E, in_channels]
        etaij = torch.sigmoid(self.linA(x_i) + self.linB(x_j))
        # self.linU(x_i) + etaij * self.linV(x_j)
        return etaij * self.linV(x_j)

    def update(self, aggr_out, x):
        # aggr_out has shape [N, out_channels]
        return aggr_out + self.linU(x)


############################################################################
class GatedEdgeConv(MessagePassing):
    def __init__(self, in_channels, out_channels):
        super(GatedEdgeConv, self).__init__(aggr='add')  # "Max" aggregation. ['add', 'mean', 'max']
        self.linB = torch.nn.Linear(in_channels, out_channels)
        self.linA = torch.nn.Linear(in_channels, out_channels)
        self.mlp = Seq(Linear(out_channels, 1 * out_channels),
                       ReLU(),
                       Linear(1 * out_channels, out_channels))
        self.sigma = 0.1 * 3.1415926  # 3.1415926*0.1

    def forward(self, x0, edge_index, edge_attr_dist):
        # x0 has shape [N, in_channels]
        # edge_index has shape [2, E]
        # edge_index, _ = remove_self_loops(edge_index)
        x = self.linB(x0)
        x = x.unsqueeze(-1) if x.dim() == 1 else x
        return self.propagate(edge_index, size=(x.size(0), x.size(0)), x=x, x0=x0, edge_attr_dist=edge_attr_dist)

    def message(self, x_i, x_j, edge_attr_dist):  # massage flow from node_j to node_i
        # # x_i has shape [E, in_channels]
        # # x_j has shape [E, in_channels]
        # # edge_attr_dist has shape E, we reshape it as [E, 1]
        edge_attr_dist = edge_attr_dist.view(-1, 1)
        # dist = torch.log(edge_attr_dist)*(-self.sigma ** 2)
        # distNorm = dist / torch.max(dist)
        # tmp = torch.cat([(x_j-x_i) * distNorm * 10], dim=1)  # tmp has shape [E, in_channels]
        # tmp_g = (self.mlp(tmp).abs() + 0.000001).pow(-1.0)
        # gate = (2 * torch.sigmoid(tmp_g) - 1)
        tmp = torch.cat([(x_j-x_i) * edge_attr_dist], dim=1)  # tmp has shape [E, in_channels]
        # tmp = torch.cat([(x_j-x_i)], dim=1)  # tmp has shape [E, in_channels]
        gate = self.mlp(tmp)
        return gate * x_j

    def update(self, aggr_out, x0):
        # aggr_out has shape [N, out_channels]

        return aggr_out + self.linA(x0)

############################################################################
class AdGatedEdgeConv(MessagePassing):
    def __init__(self, in_channels, out_channels):
        super(AdGatedEdgeConv, self).__init__(aggr='add')  # "Max" aggregation. ['add', 'mean', 'max']
        self.linB = torch.nn.Linear(in_channels, out_channels)
        self.linA = torch.nn.Linear(in_channels, out_channels)
        # self.mlp = Seq(Linear(2*out_channels, 1 * out_channels),
        #                ReLU(),
        #                Linear(1 * out_channels, out_channels))
        self.mlp = Seq(Linear(2 * out_channels, 1 * out_channels))
        # self.sigma = 0.1 * 3.1415926  # 3.1415926*0.1

    def forward(self, x0, edge_index, edge_attr_dist):
        # x0 has shape [N, in_channels]
        # edge_index has shape [2, E]
        # edge_index, _ = remove_self_loops(edge_index)
        x = self.linB(x0)
        x = x.unsqueeze(-1) if x.dim() == 1 else x
        return self.propagate(edge_index, size=(x.size(0), x.size(0)), x=x, x0=x0, edge_attr_dist=edge_attr_dist)

    def message(self, x_i, x_j, edge_attr_dist):  # massage flow from node_j to node_i
        # # x_i has shape [E, in_channels]
        # # x_j has shape [E, in_channels]
        # # edge_attr_dist has shape E, we reshape it as [E, 1]
        edge_attr_dist = edge_attr_dist.view(-1, 1)
        # dist = torch.log(edge_attr_dist)*(-self.sigma ** 2)
        # distNorm = dist / torch.max(dist)
        # tmp = torch.cat([(x_j-x_i) * distNorm * 10], dim=1)  # tmp has shape [E, in_channels]
        # tmp_g = (self.mlp(tmp).abs() + 0.000001).pow(-1.0)
        # gate = (2 * torch.sigmoid(tmp_g) - 1)
        # tmp = torch.cat([(x_j-x_i) * edge_attr_dist], dim=1)  # tmp has shape [E, in_channels]
        tmp = torch.cat((x_j, x_i), dim=1) * edge_attr_dist # tmp has shape [E, in_channels]
        gate = 2 * torch.sigmoid(self.mlp(tmp) - 1)
        return gate * x_j

    def update(self, aggr_out, x0):
        # aggr_out has shape [N, out_channels]
        return aggr_out + self.linA(x0)
######################################################################################
class DynamicGatedEdgeConv(MessagePassing):
    def __init__(self, in_channels, out_channels):
        super(DynamicGatedEdgeConv, self).__init__(aggr='add')  # "Max" aggregation. ['add', 'mean', 'max']
        self.k = 32
        self.linB = torch.nn.Linear(in_channels, out_channels)
        self.linA = torch.nn.Linear(in_channels, out_channels)
        self.mlp = Seq(Linear(out_channels, 2 * out_channels),
                       ReLU(),
                       Linear(2 * out_channels, out_channels))
        # self.sigma = 0.1 * 3.1415926  # 3.1415926*0.1

    def forward(self, x0, batch=None):
        # x has shape [N, in_channels]
        # edge_index has shape [2, E]
        # edge_index, _ = remove_self_loops(edge_index)
        x = self.linB(x0)
        edge_index = knn_graph(x, self.k, batch, loop=False, flow=self.flow)
        x = x.unsqueeze(-1) if x.dim() == 1 else x
        return self.propagate(edge_index, size=(x.size(0), x.size(0)), x=x, x0=x0)

    def message(self, x_i, x_j):  # massage flow from node_j to node_i
        # x_i has shape [E, in_channels]
        # x_j has shape [E, in_channels]
        tmp = torch.cat([(x_j-x_i)], dim=1)  # tmp has shape [E, in_channels]
        gate = self.mlp(tmp)
        return gate * x_j

    def update(self, aggr_out, x0):
        # aggr_out has shape [N, out_channels]

        return aggr_out + self.linA(x0)
######################################################################################


class NodeAtt(nn.Module):
    def __init__(self, in_channels):
        super(NodeAtt, self).__init__()
        self.mlp = Seq(Linear(1 * in_channels, in_channels),
                       ReLU(),
                       Linear(in_channels, 1))
        self.lin = Linear(1 * in_channels, in_channels)

    def forward(self, x_S, x_D):
        # x_S has shape [N, in_channels]
        # x_D has shape [N, in_channels]
        # x = torch.cat([x_S, x_D], dim=1)  # x has shape [N, 2*in_channels]
        x = x_S + x_D  # x has shape [N, 1*in_channels]
        nodeatt = torch.sigmoid(self.mlp(x))  # has shape [N, 1]
        x_out = self.lin(x * nodeatt)  # [N, in_channels]
        return x_out


class NodeAtt_wo(nn.Module):
    def __init__(self, in_channels):
        super(NodeAtt_wo, self).__init__()

    def forward(self, x_S, x_D):
        # x_S has shape [N, in_channels]
        # x_D has shape [N, in_channels]
        # x = torch.cat([x_S, x_D], dim=1)  # x has shape [N, 2*in_channels]
        x_out = x_S + x_D  # x has shape [N, 1*in_channels]
        return x_out







########################################################################
from torch import nn

# 0~1 normalization.
def MaxMinNormalization(x):
    Max = torch.max(x)
    Min = torch.min(x)
    x = torch.div(torch.sub(x, Min), 0.0001 + torch.sub(Max, Min))
    return x


def euc_dist(x):  # x is BNC
    sigma = 1
    t1 = x.unsqueeze(2)  # BN1C
    t2 = x.unsqueeze(1)  # B1NC
    # d = torch.sqrt((t1 - t2).pow(2).sum(3))
    d = (t1 - t2).pow(2).sum(3)
    d = torch.exp(-d/(2*sigma**2))
    return d  # BNN


class TransBasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size=2, stride=2, padding=0, dilation=1, bias=False):
        super(TransBasicConv2d, self).__init__()
        self.Deconv = nn.ConvTranspose2d(in_planes, out_planes,
                                         kernel_size=kernel_size, stride=stride,
                                         padding=padding, dilation=dilation, bias=bias)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.Deconv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x

class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x

def weight_init(module):
    for n, m in module.named_children():
        print('initialize: '+n)
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, (nn.BatchNorm2d, nn.InstanceNorm2d)):
            nn.init.ones_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Sequential):
            weight_init(m)
        elif isinstance(m, nn.ReLU):
            pass
        else:
            m.initialize()


# class SpatialAttention(nn.Module):
#     def __init__(self):
#         super(SpatialAttention, self).__init__()
#         self.conv1 = nn.Conv2d(1, 1, kernel_size=3, padding=1, bias=True)
#         self.sigmoid = nn.Sigmoid()
#
#     def forward(self, x):
#         max_out, _ = torch.max(x, dim=1, keepdim=True)
#         x = max_out
#         x = self.conv1(x)
#         return self.sigmoid(x)

class SpatialAttention(nn.Module):  #SA
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(1, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = max_out
        x = self.conv1(x)
        return self.sigmoid(x)

class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()

        self.max_pool = nn.AdaptiveMaxPool2d(1)  # input is BCHW, output is BC11

        self.fc1 = nn.Conv2d(in_planes, in_planes // 16, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // 16, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))  # input is BCHW, output is BC11
        out = max_out
        return self.sigmoid(out)


class LayAtt(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(LayAtt, self).__init__()
        # self.conv0 = nn.Conv2d(1, 1, 7, padding=3, bias=True)
        self.conv1 = nn.Sequential(BasicConv2d(in_channel, in_channel//2, 3, padding=1),
                                   BasicConv2d(in_channel//2, in_channel, 3, padding=1))
        self.channel = out_channel

    def forward(self, x, y):
        # a = torch.sigmoid(self.conv0(y))  # y is B 1 H W
        a = torch.sigmoid(y)  # y is B 1 H W
        x_att = self.conv1(a.expand(-1, self.channel, -1, -1).mul(x))  # -1 means not changing the size of that dimension
        x = x #+ x_att
        return x

    def initialize(self):
        weight_init(self)

class RA(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(RA, self).__init__()
        self.convert = nn.Conv2d(in_channel, out_channel, 1, bias=False)
        self.bn = nn.BatchNorm2d(out_channel)
        self.relu = nn.ReLU(True)
        self.convs = nn.Sequential(
            nn.Conv2d(out_channel, out_channel, 3, padding=1, bias=False), nn.BatchNorm2d(out_channel), nn.ReLU(True),
            nn.Conv2d(out_channel, out_channel, 3, padding=1, bias=False), nn.BatchNorm2d(out_channel), nn.ReLU(True),
            nn.Conv2d(out_channel, out_channel, 3, padding=1, bias=False), nn.BatchNorm2d(out_channel), nn.ReLU(True),
            nn.Conv2d(out_channel, 1, 3, padding=1),
        )
        self.channel = out_channel

    def forward(self, x, y):
        a = torch.sigmoid(-y)  # y is B 1 H W
        x = self.relu(self.bn(self.convert(x)))
        x = a.expand(-1, self.channel, -1, -1).mul(x)  # -1 means not changing the size of that dimension
        y = y + self.convs(x)
        return y

    def initialize(self):
        weight_init(self)


class NodeAtt(nn.Module):
    def __init__(self, in_channels):
        super(NodeAtt, self).__init__()
        self.mlp = nn.Sequential(nn.Linear(1 * in_channels, in_channels),
                                 nn.ReLU(),
                                 nn.Linear(in_channels, 1))
        self.lin = nn.Linear(1 * in_channels, in_channels)

    def forward(self, x):  # x has shape [N, 1*in_channels]
        nodeatt = torch.sigmoid(self.mlp(x))  # has shape [N, 1]
        x_out = self.lin(x * nodeatt) + x   # [N, in_channels]
        return x_out


########################################################################
from torch import nn
from torch_geometric.utils import dense_to_sparse
import torch.nn.functional as F


def Generate_edges_inside_a_block(adj, bndnum, thr, B, x_t, node_num, bknum):  # x is [B, C, node_num]
    edge_index = []
    edge_attr = []
    data = []
    batch = []
    adj = torch.where(adj < thr, torch.zeros_like(adj), adj)
    adj_new = torch.zeros_like(adj)
    for k in range(bknum*bknum):
        adj_new[:, k*bndnum:(k+1)*bndnum, k*bndnum:(k+1)*bndnum] = adj[:, k*bndnum:(k+1)*bndnum, k*bndnum:(k+1)*bndnum]
    # img_show(adj_new)
    for i in range(B):
        edge_index_i, edge_attr_i = dense_to_sparse(adj_new[i])  # [2, node_connect], [node_connect]
        edge_index.append(edge_index_i + i*node_num)
        edge_attr.append(edge_attr_i)
        data.append(x_t[i])  # x_t[i] is [node_num, C]
        batch.append(torch.LongTensor(node_num).fill_(i))
    graph_data = torch.cat(data, dim=0)
    graph_edge_index = torch.cat(edge_index, dim=1)
    graph_edge_attr = torch.cat(edge_attr, dim=0)
    graph_batch = torch.cat(batch, dim=0).to(adj.device)
    return graph_data, graph_edge_index, graph_edge_attr, B, graph_batch
    # [node_num_batch, C], [2, node_connect_batch], [node_connect_batch]

def Generate_edges_between_blocks(adj, bndnum, thr, B, x_t, node_num, bknum):  # x is [B, C, node_num]
    edge_index = []
    edge_attr = []
    data = []
    batch = []
    adj = torch.where(adj < thr, torch.zeros_like(adj), adj)
    adj_new = torch.zeros_like(adj)
    for k in range(int(bknum * bknum / 2)):
        k = k*2
        adj_new[:, k * bndnum:(k + 2) * bndnum, k * bndnum:(k + 2) * bndnum] = adj[:, k * bndnum:(k + 2) * bndnum, k * bndnum:(k + 2) * bndnum]
    adj_new[:, 0 * bndnum:(0 + 2) * bndnum, 4 * bndnum:(4 + 2) * bndnum] = adj[:, 0 * bndnum:(0 + 2) * bndnum, 4 * bndnum:(4 + 2) * bndnum]
    adj_new[:, 2 * bndnum:(2 + 2) * bndnum, 6 * bndnum:(6 + 2) * bndnum] = adj[:, 2 * bndnum:(2 + 2) * bndnum, 6 * bndnum:(6 + 2) * bndnum]
    adj_new[:, 4 * bndnum:(4 + 2) * bndnum, 0 * bndnum:(0 + 2) * bndnum] = adj[:, 4 * bndnum:(4 + 2) * bndnum, 0 * bndnum:(0 + 2) * bndnum]
    adj_new[:, 6 * bndnum:(6 + 2) * bndnum, 2 * bndnum:(2 + 2) * bndnum] = adj[:, 6 * bndnum:(6 + 2) * bndnum, 2 * bndnum:(2 + 2) * bndnum]
    adj_new[:, 8 * bndnum:(8 + 2) * bndnum, 12 * bndnum:(12 + 2) * bndnum] = adj[:, 8 * bndnum:(8 + 2) * bndnum, 12 * bndnum:(12 + 2) * bndnum]
    adj_new[:, 10 * bndnum:(10 + 2) * bndnum, 14 * bndnum:(14 + 2) * bndnum] = adj[:, 10 * bndnum:(10 + 2) * bndnum, 14 * bndnum:(14 + 2) * bndnum]
    adj_new[:, 12 * bndnum:(12 + 2) * bndnum, 8 * bndnum:(8 + 2) * bndnum] = adj[:, 12 * bndnum:(12 + 2) * bndnum, 8 * bndnum:(8 + 2) * bndnum]
    adj_new[:, 14 * bndnum:(14 + 2) * bndnum, 10 * bndnum:(10 + 2) * bndnum] = adj[:, 14 * bndnum:(14 + 2) * bndnum, 10 * bndnum:(10 + 2) * bndnum]
    # img_show(adj_new)
    for i in range(B):
        edge_index_i, edge_attr_i = dense_to_sparse(adj_new[i])  # [2, node_connect], [node_connect]
        edge_index.append(edge_index_i + i * node_num)
        edge_attr.append(edge_attr_i)
        data.append(x_t[i])  # x_t[i] is [node_num, C]
        batch.append(torch.LongTensor(node_num).fill_(i))
    graph_data = torch.cat(data, dim=0)
    graph_edge_index = torch.cat(edge_index, dim=1)
    graph_edge_attr = torch.cat(edge_attr, dim=0)
    graph_batch = torch.cat(batch, dim=0).to(adj.device)
    return graph_data, graph_edge_index, graph_edge_attr, B, graph_batch  # [node_num_batch, C], [2, node_connect_batch], [node_connect_batch]


def thr_select(adj, k):  # adj  B*N*N
    B, N, N = adj.size()
    adj_flat = adj.view(B,-1)  # B*(N*N)
    adj_uniq = torch.unique(adj_flat,dim=1)
    val, _ = adj_uniq.topk(k, dim=1, largest=True, sorted=True)  # val is B*k
    thr = val[:,k-1]  #B
    return thr.unsqueeze(1).unsqueeze(2)  # B*1*1


def Generate_edges_globally(adj, bndnum, thr, B, x_t, node_num, bknum):  # x is [B, C, node_num]
    edge_index = []
    edge_attr = []
    data = []
    batch = []
    adj = torch.where(adj < thr, torch.zeros_like(adj), adj)
    for i in range(B):
        edge_index_i, edge_attr_i = dense_to_sparse(adj[i])  # [2, node_connect], [node_connect]
        edge_index.append(edge_index_i + i*node_num)
        edge_attr.append(edge_attr_i)
        data.append(x_t[i])  # x_t[i] is [node_num, C]
        batch.append(torch.LongTensor(node_num).fill_(i))
    graph_data = torch.cat(data, dim=0)
    graph_edge_index = torch.cat(edge_index, dim=1)
    graph_edge_attr = torch.cat(edge_attr, dim=0)
    graph_batch = torch.cat(batch, dim=0).to(adj.device)
    return graph_data, graph_edge_index, graph_edge_attr, B, graph_batch  # [node_num_batch, C], [2, node_connect_batch], [node_connect_batch]


def graph_batch_re_trans(x, B, node_num_batch, C_new):  # x is [node_num_batch, C_new]
    node_num = int(node_num_batch/B)
    data = torch.zeros([B, node_num, C_new], device=x.device, dtype=x.dtype, layout=x.layout)
    for i in range(B):
        ind_s = i*node_num
        ind_e = (i+1)*node_num
        data[i] = x[ind_s:ind_e,:]
    data_o = data.permute(0, 2, 1).contiguous()  # [B, node_num_batch, C_new]→[B, C_new, node_num_batch]
    return data_o  # [B, C_new, node_num_batch]



class GraphInference(nn.Module):
    def __init__(self, dim, loop, bknum, thr4, thr2, thr1):
        super(GraphInference, self).__init__()
        self.thr4 = thr4
        self.thr2 = thr2
        self.thr1 = thr1
        self.bknum = bknum
        self.loop = loop
        self.gcn1 = AdGatedEdgeConv(dim, dim)
        self.gcn2 = AdGatedEdgeConv(dim, dim)
        self.gcn3 = AdGatedEdgeConv(dim, dim)
        self.gcns = [self.gcn1, self.gcn2, self.gcn3]

        self.bn1 = BatchNorm(dim)
        self.bn2 = BatchNorm(dim)
        self.bn3 = BatchNorm(dim)
        self.bns = [self.bn1, self.bn2, self.bn3]

        self.Att1 = NodeAtt(dim)
        self.Att2 = NodeAtt(dim)
        self.Att3 = NodeAtt(dim)
        self.Atts = [self.Att1, self.Att2, self.Att3]

        assert (loop == 0 or loop == 1 or loop == 2 or loop == 3)
        self.gcns = self.gcns[0:loop]
        self.bns = self.bns[0:loop]
        self.Atts = self.Atts[0:loop]

        self.relu = nn.ReLU()
        self.lineA4 = torch.nn.Linear(dim, 1)
        self.lineA2 = torch.nn.Linear(dim, 1)
        self.lineA1 = torch.nn.Linear(dim, 1)
        self.mlpCA4 = torch.nn.Sequential(torch.nn.Linear(dim, dim),
                                          torch.nn.ReLU(),
                                          torch.nn.Linear(dim, dim))
        self.mlpCA2 = torch.nn.Sequential(torch.nn.Linear(dim, dim),
                                          torch.nn.ReLU(),
                                          torch.nn.Linear(dim, dim))
        self.mlpCA1 = torch.nn.Sequential(torch.nn.Linear(dim, dim),
                                          torch.nn.ReLU(),
                                          torch.nn.Linear(dim, dim))
        self.lineA = torch.nn.Linear(3, 3)
        self.lineFu = torch.nn.Linear(dim, dim)

    def forward(self, x):  # x is [B, C, node_num]
        B, C, node_num = x.size()
        bndnum = int(node_num / (self.bknum * self.bknum))
        x = F.normalize(x, p=2, dim=1)  # 即对每个节点按照通道维度C进行2范数Norm，每个节点的所有通道值均在0-1之间；
        x_t = x.permute(0, 2, 1).contiguous()  # x_t is [B, node_num, C]
        # adj = euc_dist(x_t)  # dist_adj is [B, node_num, node_num]
        adj = (torch.matmul(x_t, x))  # adj is [B, node_num, node_num]

        graph_data4, edge_index4, edge_attr4, B, graph_batch4 = Generate_edges_inside_a_block(adj, bndnum, self.thr4, B, x_t, node_num, self.bknum)
        # x is [B, C, node_num], output is [node_num_batch, C], [2, node_connect_batch], [node_connect_batch]
        y4 = self.relu(self.Atts[0](self.bns[0](self.gcns[0](graph_data4, edge_index4, edge_attr4)) + graph_data4))

        graph_data2, edge_index2, edge_attr2, B, graph_batch2 = Generate_edges_between_blocks(adj, bndnum, self.thr2, B, x_t, node_num, self.bknum)
        # x is [B, C, node_num], output is [node_num_batch, C], [2, node_connect_batch], [node_connect_batch]
        y2 = self.relu(self.Atts[1](self.bns[1](self.gcns[1](graph_data2, edge_index2, edge_attr2)) + graph_data2))

        graph_data1, edge_index1, edge_attr1, B, graph_batch1 = Generate_edges_globally(adj, bndnum, self.thr1, B, x_t, node_num, self.bknum)
        # x is [B, C, node_num], output is [node_num_batch, C], [2, node_connect_batch], [node_connect_batch]
        y1 = self.relu(self.Atts[2](self.bns[2](self.gcns[2](graph_data1, edge_index1, edge_attr1)) + graph_data1))

        w4 = torch.sigmoid(self.mlpCA4(global_max_pool(y4, graph_batch4)))  # B*C_new，channel-wise Attention
        w2 = torch.sigmoid(self.mlpCA2(global_max_pool(y2, graph_batch2)))
        w1 = torch.sigmoid(self.mlpCA1(global_max_pool(y1, graph_batch1)))

        a4 = self.lineA4(w4)  # B*1
        a2 = self.lineA2(w2)
        a1 = self.lineA1(w1)
        A = torch.cat((a4, a2, a1), dim=1)
        A = F.softmax(A, dim=1)
        W4 = w4[graph_batch4]  # (B*node_num)*C_new
        A4 = A[:, 0][graph_batch4]  # (B*node_num)*1
        W2 = w2[graph_batch2]
        A2 = A[:, 1][graph_batch2]  # (B*node_num)*1
        W1 = w1[graph_batch1]
        A1 = A[:, 2][graph_batch1]  # (B*node_num)*1
        y = self.lineFu(A4.unsqueeze(1) * W4 * y4 + A2.unsqueeze(1) * W2 * y2 + A1.unsqueeze(1) * W1 * y1)
        node_num_batch, C_new = y.size()
        output = graph_batch_re_trans(y, B, node_num_batch, C_new)  # trans from [node_num_batch, C_new] to [B, C_new, node_num]
        return output  # [B, C_new, node_num]


class GraphProjection(nn.Module):
    def __init__(self,bnum,bnod,dim,normalize_input=False):
        super(GraphProjection, self).__init__()
        self.bnum=bnum
        self.bnod=bnod
        self.node_num=bnum*bnum*bnod
        self.dim = dim
        self.normalize_input = normalize_input
        self.anchor = nn.Parameter(torch.rand(self.node_num, dim))
        self.sigma = nn.Parameter(torch.rand(self.node_num, dim))
        #随机初始化w与σ

    def gen_soft_assign(self, x, sigma):
        B, C, H, W = x.size()
        soft_assign = torch.zeros([B, self.node_num, self.n], device=x.device, dtype=x.dtype, layout=x.layout)#这一步是初始化软分配矩阵,torch.zeros() 返回一个形状为为size,类型为torch.dtype，里面的每一个值都是0的tensor
        soft_ass = torch.zeros([B, self.node_num, self.n], device=x.device, dtype=x.dtype, layout=x.layout)
        for node_id in range(self.node_num):
            block_id=math.floor(node_id/self.bnod)
            h_sta=math.floor(block_id/self.bnum)*self.h
            w_sta=block_id%(self.bnum)*self.w
            h_end=h_sta+self.h
            w_end=w_sta+self.w
            tmp=x.view(B, C, H, W)[: , : ,h_sta:h_end , w_sta : w_end]
            tmp=tmp.reshape(B,C,-1).permute(0,2,1).contiguous()
            residual = (tmp - self.anchor[node_id, :]).div(sigma[node_id, :]) # + eps)
            soft_assign[:, node_id, :] = -torch.pow(torch.norm(residual, dim=2),2)/2
        for block_id in range(self.bnum*self.bnum):
            node_sta=self.bnod*block_id
            node_end=node_sta+self.bnod
            soft_ass[: , node_sta:node_end , :]=F.softmax(soft_assign[: , node_sta:node_end , :], dim=1)#对矩阵计算软赋值，形成最终的软分配矩阵
        return soft_ass #B node_num n

    def forward(self, x):
        B, C, H, W = x.size()
        self.h=math.floor(H/self.bnum)
        self.w=math.floor(W/self.bnum)
        self.n=self.h*self.w
        if self.normalize_input:
            x = F.normalize(x, p=2, dim=1)  #across descriptor dim
        sigma = torch.sigmoid(self.sigma)
        soft_assign = self.gen_soft_assign(x, sigma)    # B x node_num x N(N=HxW)
        eps = 1e-9
        nodes = torch.zeros([B, self.node_num, C], dtype=x.dtype, layout=x.layout, device=x.device)
        for node_id in range(self.node_num):
            block_id=math.floor(node_id/self.bnod)
            h_sta=math.floor(block_id/self.bnum)*self.h
            w_sta=block_id%(self.bnum)*self.w
            h_end=h_sta+self.h
            w_end=w_sta+self.w
            tmp=x.view(B, C, H, W)[: , : ,h_sta:h_end , w_sta : w_end]
            tmp=tmp.reshape(B,C,-1).permute(0,2,1).contiguous()
            residual = (tmp - self.anchor[node_id, :]).div(sigma[node_id, :]) # + eps)

            nodes[:, node_id, :] = residual.mul(soft_assign[:, node_id, :].unsqueeze(2)).sum(dim=1) / (soft_assign[:, node_id, :].sum(dim=1).unsqueeze(1) + eps)
            # nodes[:, node_id, :] = residual.mul(soft_assign[:, node_id, :].unsqueeze(2)).sum(dim=1)
            #        [B,C]         [B,n,C]              [B,n]              [B,n,1]       [B,C]                [B,n]                [B]        [B,1]
        nodes = F.normalize(nodes, p=2, dim=2) #intra-normalization
        nodes = nodes.view(B, -1).contiguous() # B X (Node_num X C)
        nodes = F.normalize(nodes, p=2, dim=1) # l2 normalize
        return nodes.view(B, self.node_num, C).permute(0,2,1).contiguous(), soft_assign
        # B*C*node，B * node * n


class GraphProcess(nn.Module):
    def __init__(self, bnum, bnod, dim, loop, thr4, thr2, thr1):
        super(GraphProcess, self).__init__()
        self.loop = loop
        self.bnum = bnum
        self.bnod = bnod
        self.dim = dim
        self.node_num = bnum*bnum*bnod
        self.proj = GraphProjection(self.bnum, self.bnod, self.dim)
        self.gconv = GraphInference(self.dim, self.loop, self.bnum, thr4, thr2, thr1)

    def GraphReprojection(self,Q,Z):
        self.B, self.Dim, _ = Z.size()
        res=torch.zeros([self.B,self.Dim,self.H,self.W], device=Z.device, dtype=Z.dtype, layout=Z.layout)
        for node_id in range(self.node_num):
            block_id=math.floor(node_id/self.bnod)
            h_sta=math.floor(block_id/self.bnum)*self.h
            w_sta=block_id%(self.bnum)*self.w
            h_end=h_sta+self.h
            w_end=w_sta+self.w
            res[:,:, h_sta:h_end , w_sta:w_end]+=torch.matmul(Z[:,:,node_id].unsqueeze(2),Q[:,node_id,:].unsqueeze(1)).view(self.B,self.Dim,self.h,self.w)
        return res

    def forward(self, x):  #
        _, _, self.H, self.W = x.size()
        self.h = math.floor(self.H / self.bnum)
        self.w = math.floor(self.W / self.bnum)
        g, Q = self.proj(x)
        g = self.gconv(g)
        res = self.GraphReprojection(Q, g) + x
        res.to(x.device)
        return res


class DSIModule(nn.Module):
    def __init__(self,channel):
        super(DSIModule, self).__init__()
        self.dim=channel
        self.gcnlayer=GraphProcess(bnum=7, bnod=2, dim=512, loop=3, thr4=0.2, thr2=0.4, thr1=0.6)

        self.conv=BasicConv2d(self.dim, 512, kernel_size=1,stride=1)

        self.downsample2 = nn.MaxPool2d(2,stride=2)
        self.downsample4 = nn.MaxPool2d(4,stride=4)
        self.downsample8 = nn.MaxPool2d(8,stride=8)

    def forward(self,x1,x2,x3,x4,x5):
        x3 = self.downsample8 (x3)
        x4 = self.downsample4 (x4)
        x5 = self.downsample2 (x5)
        x=torch.cat((x3,x4,x5),dim=1)
        x=self.conv(x)
        x=self.gcnlayer(x)+x
        return x
#################################################################

class MSAM(nn.Module):
    def __init__(self, channel):
        super(MSAM, self).__init__()
        self.upSA = SpatialAttention()
        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.downsample2 = nn.MaxPool2d(2, stride=2)

        self.conv_mid1 = BasicConv2d(channel, channel // 8, 3, padding=1, dilation=1)
        self.conv_mid2 = BasicConv2d(channel, channel // 8, 3, padding=2, dilation=2)
        self.conv_mid3 = BasicConv2d(channel, channel // 8, 3, padding=3, dilation=3)
        self.conv_mid4 = BasicConv2d(channel, channel // 8, 3, padding=4, dilation=4)

        self.conv_up1 = BasicConv2d(channel, channel // 8, 3, padding=1, dilation=1)
        self.conv_up2 = BasicConv2d(channel, channel // 8, 3, padding=3, dilation=3)

        self.conv_down1 = BasicConv2d(channel, channel // 8, 3, padding=1, dilation=1)
        self.conv_down2 = BasicConv2d(channel, channel // 8, 3, padding=3, dilation=3)

        self.SA = SpatialAttention()
        self.CA = ChannelAttention(channel)

    def forward(self, x, up):
        x_mid1 = self.conv_mid1(x)
        x_mid2 = self.conv_mid2(x)
        x_mid3 = self.conv_mid3(x)
        x_mid4 = self.conv_mid4(x)

        x_up1 = self.downsample2(self.conv_up1(self.upsample2(x)))
        x_up2 = self.downsample2(self.conv_up2(self.upsample2(x)))

        x_down1 = self.upsample2(self.conv_down1(self.downsample2(x)))
        x_down2 = self.upsample2(self.conv_down2(self.downsample2(x)))

        x_mix = torch.cat((x_mid1, x_mid2, x_mid3, x_mid4, x_up1, x_up2, x_down1, x_down2), dim=1)

        x_mix = x_mix * self.CA(x_mix) + x_mix
        x_mix = x_mix * self.SA(x_mix) + x_mix

        if (torch.is_tensor(up)):
            x_mix = x_mix * self.upSA(self.upsample2(up)) + x_mix

        x_mix = x_mix + x

        return x_mix

#############################################
import torch
import torch.nn as nn
import math
eps = math.exp(-10)

class AP_MP(nn.Module):
    def __init__(self, stride=2):
        super(AP_MP, self).__init__()
        self.sz = stride
        self.gapLayer = nn.AvgPool2d(kernel_size=self.sz, stride=self.sz)
        self.gmpLayer = nn.MaxPool2d(kernel_size=self.sz, stride=self.sz)

    def forward(self, x1, x2):
        B, C, H, W = x1.size()
        apimg = self.gapLayer(x1)
        mpimg = self.gmpLayer(x2)
        byimg = torch.norm(abs(apimg - mpimg), p=2, dim=1, keepdim=True)
        return byimg


class MSCM(nn.Module):
    def __init__(self, channel):
        super(MSCM, self).__init__()
        self.channel = channel

        self.conv1 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv2 = BasicConv2d(channel, channel, 3, padding=1)

        self.CA1 = ChannelAttention(self.channel)
        self.CA2 = ChannelAttention(self.channel)
        self.SA1 = SpatialAttention()
        self.SA2 = SpatialAttention()

        self.glbamp = AP_MP()

        self.conv = BasicConv2d(channel * 2 + 1, channel, kernel_size=1, stride=1)

        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.upSA = SpatialAttention()

    def forward(self, x, up):
        x1 = self.conv1(x)
        x2 = self.conv2(x)
        if (torch.is_tensor(up)):
            x2 = x2 * self.upSA(self.upsample2(up)) + x2

        x1 = x1 + x1 * self.CA1(x1)
        x2 = x2 + x2 * self.CA2(x2)

        nx1 = x1 + x1 * self.SA2(x2)
        nx2 = x2 + x2 * self.SA1(x1)

        gamp = self.upsample2(self.glbamp(nx1, nx2))

        res = self.conv(torch.cat([nx1, gamp, nx2], dim=1))

        return res + x

class MSCM1(nn.Module):
    def __init__(self, channel):
        super(MSCM1, self).__init__()
        self.channel = channel

        self.conv1 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv2 = BasicConv2d(channel, channel, 3, padding=1)

        self.CA1 = ChannelAttention(self.channel)
        self.CA2 = ChannelAttention(self.channel)
        self.SA1 = SpatialAttention()
        self.SA2 = SpatialAttention()

        self.glbamp = AP_MP()

        self.conv = BasicConv2d(channel * 2 + 1, channel, kernel_size=1, stride=1)

        self.upsample2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.upSA = SpatialAttention()

    def forward(self, x, up):

        x1 = self.conv1(x)
        x2 = self.conv2(x)
        if (torch.is_tensor(up)):
            x2 = x2 * self.upSA(up) + x2

        x1 = x1 + x1 * self.CA1(x1)
        x2 = x2 + x2 * self.CA2(x2)

        nx1 = x1 + x1 * self.SA2(x2)
        nx2 = x2 + x2 * self.SA1(x1)

        gamp = self.upsample2(self.glbamp(nx1, nx2))

        res = self.conv(torch.cat([nx1, gamp, nx2], dim=1))

        return res + x